// DONE: Faire l'entête de fichier
/********************************************
 * Titre: Travail pratique #2 - Auteur.cpp
 * Date: 11 Févrié 2020
 * Auteur: Simon Gauvin
 * Modifié par:
 * ZIGGAR ÉLISÉE MAPHI 1822555
 * PAUL CALANGE        2053113
 *******************************************/


#include "Auteur.h"
#include <iostream>

//! Constructeur de la classe Auteur
//! \param nom              Nom de l'auteur
//! \param anneeDeNaissance Année de naissance de l'auteur
Auteur::Auteur(const std::string& nom, unsigned int anneeDeNaissance)
    : nom_(nom)
    , anneeDeNaissance_(anneeDeNaissance)
    , nbFilms_(0)
{
}

//! Méthode qui affiche un auteur
//! \param stream Le stream dans lequel afficher
// void Auteur::afficher(std::ostream& stream) const
//{
//    // Ne modifiez pas cette fonction
//    stream << "Nom: " << nom_ << " | Date de naissance: " << anneeDeNaissance_
//           << " | Nombre de films: " << nbFilms_;
//}
std::ostream& operator<<(std::ostream& os, const Auteur auteur)
{
    os << "Nom: " << auteur.nom_ << " | Date de naissance: " << auteur.anneeDeNaissance_
       << " | Nombre de films: " << auteur.nbFilms_;
    return os;
}


//! Méthode de la classe Auteur qui permet de comparer un auteur
//! avec un nom pris en paramettre.
//! \return un booleen vrai si le string est le même que le nom de
//\ de l'auteur sinon retourne false.
bool Auteur::operator==(std::string const nom) const
{
    if (nom_ == nom)
    {
        return true;
    }
    else
    {
        return false;
    }
}


//! Méthode global avec un access privilegier au attributs 
//! de la classe Auteur et permet de comparer un nom avec un auteur 
//! \return un booleen vrai si le string est le même que le nom de 
//\ de l'auteur, sinon elle retourne false. 
bool operator==(std::string const nom, const Auteur& auteur)
{
    if (auteur.nom_== nom)
    {
        return true;
    }
    else
    {
        return false;
    }
}


//! Méthode qui retourne le nom de l'auteur
//! \return Le nom de l'auteur
const std::string& Auteur::getNom() const
{
    return nom_;
}

//! Méthode qui retourne l'année de naissance de l'auteur
//! \return L'année de naissance de l'auteur
unsigned int Auteur::getAnneeDeNaissance() const
{
    return anneeDeNaissance_;
}



//! Méthode qui retourne le nombre de films de l'auteur
//! \return Le nombre de films de l'auteur
unsigned int Auteur::getNbFilms() const
{
    return nbFilms_;
}



//! Méthode qui set le nombre de films de l'auteur
//! \param nbFilms  Le nombre de films de l'auteur
void Auteur::setNbFilms(unsigned int nbFilms)
{
    nbFilms_ = nbFilms;
}